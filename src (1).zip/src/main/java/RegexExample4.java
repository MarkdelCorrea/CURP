import java.util.regex.Pattern;
public class RegexExample4 {

    public static void main(String args[]){
        System.out.println("\'[amn]?\' Cuantificador ? indica que puede ocurrir 0 o 1 vez:");

        //true (a or m or n comes one time)
        System.out.println(Pattern.matches("[amn]?", "a"));

        //false (a comes more than one time)
        System.out.println(Pattern.matches("[amn]?", "aaa"));

        //false (a m and n comes more than one time)
        System.out.println(Pattern.matches("[amn]?", "aammmnn"));

        //false (a comes more than one time)
        System.out.println(Pattern.matches("[amn]?", "aazzta"));

        //false (a or m or n must come one time)
        System.out.println(Pattern.matches("[amn]?", "am"));

        System.out.println("\'[amn]+\' Cuantificador + indica que al menos debe aparecer lo anterior 1 vez, sin límite máximo:");

        //true (a or m or n once or more times)
        System.out.println(Pattern.matches("[amn]+", "a"));

        //true (a comes more than one time)
        System.out.println(Pattern.matches("[amn]+", "aaa"));

        //true (a or m or n comes more than once)
        System.out.println(Pattern.matches("[amn]+", "aammmnn"));

        //false (z and t are not matching pattern)
        System.out.println(Pattern.matches("[amn]+", "aazzta"));

        System.out.println("\'[amn]*\' Cuantificador * indica que lo precedente al símbolo puede aparecer 0 o n veces");

        //true (a or m or n may come zero or more times)
        System.out.println(Pattern.matches("[amn]*", "ammmna"));

    }
}
