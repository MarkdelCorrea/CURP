package validate;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

public class ValidaFecha {

    private static final Logger LOG = Logger.getLogger("validate.ValidaFecha");

    public static void main(String args[]) {

        LOG.setLevel(Level.WARNING);

        if(args.length == 0) {
            LOG.severe("No se proporciono la fecha.");
            System.exit(1);
        }

        String dateString = args[0];

        if( checkShortDate(dateString )) {
            System.out.printf("La fecha %s es valida en formato simple.%n",dateString);
            LOG.info("OK");
        } else {
            System.out.printf("La fecha %s no es valida en formato simple.%n",dateString);
            LOG.info("FAIL");
        }

        if( checkLongDate(dateString )) {
            System.out.printf("La fecha %s es valida en formato largo.%n",dateString);
            LOG.info("OK");
        } else {
            System.out.printf("La fecha %s no es valida en formato largo.%n",dateString);
            LOG.info("FAIL");
        }
    }

    public static boolean checkShortDate(String date ) {
        boolean isCorrect = false;

        final String simpleDateRx = "\\d{1,2}/\\d{1,2}/\\d{4}";

        isCorrect = Pattern.matches(simpleDateRx,date);

        return isCorrect;
    }

    public static boolean checkLongDate(String date ) {
        boolean isCorrect = false;

        final String longDateRx = "\\d{1,2}/(?i)(ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic)/\\d{4}";

        isCorrect = Pattern.matches(longDateRx,date);

        return isCorrect;
    }


}
